import React,{Component} from 'react';
import {View,Text, Image, ScrollView, StyleSheet} from 'react-native';
export default class App extends Component{
  render(){
    return(
      <ScrollView>
      <View style = {styles.container}>
      <Image 
      source={{uri:'https://scontent.fmnl30-3.fna.fbcdn.net/v/t39.30808-6/326356039_702322334887548_1960753462535087244_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=a5f93a&_nc_eui2=AeHI55koHyQxmtmjNF53FCDWIAdw9va1QLEgB3D29rVAsY7zfWpCT41G4LECTNJyFcsRJj54l0_IRDRGzKa_p0os&_nc_ohc=Gp08G8mKrV4Q7kNvgGWNDil&_nc_ht=scontent.fmnl30-3.fna&oh=00_AYAt5nm7LW9TpaJG2hHyIh3mi2gFr25wqDYWgpPTiCGGRw&oe=66D449D6'}}
      style ={{width:200, height:200}}
      />
      <Text style={styles.text}>ZILDJIAN CABAÑERO</Text>
      <Text> </Text>
      <Text>BSIT KUNG DI PAPALARIN MAG CACALLCENTER </Text>
      <Text>3rd YEAR IRREG STUDENT NAG AARAL NG MABUTI </Text>
      </View>
      <View style={styles.container}>
      <Image
    source={{uri:'https://media.tenor.com/e70PSmKNp3YAAAAi/cat-dancing-gat.gif'}}
      style={{width:200, height:200}}
      />
      <Text style={styles.text}></Text>
      </View>
      </ScrollView>
    );
  }
}
const styles = StyleSheet.create({
  container:{
    flex:1,
    alignItems:'center',
    justifyContent:'center',
    marginVertical:20,
  },
  text:{
    fontSize:24,
    fontWeight:'bold',
    textAlign:'center',
    marginVertical:10,
  },
});
